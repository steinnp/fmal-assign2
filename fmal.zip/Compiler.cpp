#include "Parser.h"

int main(){
    Lexer *myLexer = new Lexer();
    Parser myParser(myLexer);
    myParser.parse();
    delete myLexer;
    return 0;
}
