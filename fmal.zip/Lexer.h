#include "Token.h"

class Lexer{
    public:
        Token nextToken();
};
